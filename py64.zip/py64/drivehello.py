from exeBytes import exeBytes
from pythonmemorymodule import MemoryModule
import sys
print("mapping hello.exe bytes via pythonmemorymodule...")
exe = MemoryModule(data=bytes(exeBytes))
print("mapped + entrypoint called")