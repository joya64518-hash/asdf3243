from pathlib import Path
import subprocess
import sys
import winreg


folder = Path(__file__).resolve().parent
python = folder / "python.exe"
app = (folder / sys.argv[1]).resolve()

if not python.is_file():
    raise FileNotFoundError(python)
if not app.is_file():
    raise FileNotFoundError(app)

command = subprocess.list2cmdline([str(python), str(Path(__file__).resolve()), str(app)])
with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as key:
    winreg.SetValueEx(key, "WallpaperSystem", 0, winreg.REG_SZ, command)

subprocess.Popen([str(python), str(app)], cwd=str(app.parent))
